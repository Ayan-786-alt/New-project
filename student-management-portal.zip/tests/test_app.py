import os
import tempfile
import pytest
from app import app, init_db

@pytest.fixture()
def client():
    db_fd, db_path = tempfile.mkstemp()
    app.config["TESTING"] = True
    import app as app_module
    app_module.DB_PATH = db_path
    init_db()
    with app.test_client() as client:
        yield client
    os.close(db_fd)
    os.unlink(db_path)

def test_dashboard_loads(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Student Management Portal" in response.data

def test_add_student(client):
    response = client.post("/students/add", data={
        "roll_no": "BCA001",
        "name": "Test Student",
        "email": "test@example.com",
        "course": "BCA",
        "semester": "3",
        "attendance": "88",
        "marks": "82"
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b"Test Student" in response.data

def test_api(client):
    response = client.get("/api/students")
    assert response.status_code == 200
    assert response.json == []
