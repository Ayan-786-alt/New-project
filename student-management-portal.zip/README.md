# Student Management Portal

A clean, job-ready full-stack BCA portfolio project built with **Python, Flask, SQLite, HTML, CSS and JavaScript**.

## Why this project?
It demonstrates practical software-development skills expected from a BCA fresher: CRUD operations, relational data, server-side routing, API development, validation, responsive UI, automated tests and Git/GitHub workflow.

## Features
- Dashboard with student statistics
- Add and delete student records
- Search students by roll number, name or course
- Attendance and marks tracking
- SQLite persistence
- Responsive UI
- JSON API at `/api/students`
- Validation and error handling
- Pytest test suite
- Clean project documentation

## Tech stack
| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, JavaScript |
| Backend | Python, Flask |
| Database | SQLite |
| Testing | pytest |
| Version control | Git / GitHub |

## Quick start

```bash
git clone https://github.com/Ayan-786-alt/New-project.git
cd New-project
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Run:
```bash
python app.py
```

Open `http://127.0.0.1:5000`.

Run tests:
```bash
pytest
```

## API
`GET /api/students` returns all student records as JSON.

## Architecture

```text
Browser
   │
   ▼
Flask Routes ─────► Validation
   │
   ▼
SQLite Database
   │
   ▼
HTML Templates / JSON API
```

## Project structure

```text
New-project/
├── app.py
├── schema.sql
├── requirements.txt
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── templates/
│   ├── base.html
│   ├── index.html
│   └── students.html
├── static/
│   ├── style.css
│   └── app.js
└── tests/
    └── test_app.py
```

## Future enhancements
- User authentication and role-based access
- Edit student records
- Separate attendance/marks modules
- PostgreSQL deployment
- Docker support
- CI with GitHub Actions
- Export reports to CSV/PDF

## Resume-ready description

> Developed a responsive Student Management Portal using Python Flask and SQLite, implementing CRUD operations, academic performance tracking, search, REST-style JSON APIs, validation, error handling and automated testing with pytest.

## License
MIT
