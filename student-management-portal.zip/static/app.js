document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("input[type='number']").forEach((input) => {
    input.addEventListener("input", () => {
      const min = Number(input.min);
      const max = Number(input.max);
      if (input.value !== "" && Number(input.value) > max) input.value = max;
      if (input.value !== "" && Number(input.value) < min) input.value = min;
    });
  });
});
