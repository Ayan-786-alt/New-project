from flask import Flask, jsonify, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "students.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-in-production"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            roll_no TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            course TEXT NOT NULL,
            semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
            attendance REAL NOT NULL DEFAULT 0 CHECK (attendance BETWEEN 0 AND 100),
            marks REAL NOT NULL DEFAULT 0 CHECK (marks BETWEEN 0 AND 100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


@app.route("/")
def index():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) AS c FROM students").fetchone()["c"]
    avg_marks = conn.execute("SELECT COALESCE(AVG(marks), 0) AS a FROM students").fetchone()["a"]
    avg_attendance = conn.execute("SELECT COALESCE(AVG(attendance), 0) AS a FROM students").fetchone()["a"]
    at_risk = conn.execute("SELECT COUNT(*) AS c FROM students WHERE attendance < 75").fetchone()["c"]
    recent = conn.execute("SELECT * FROM students ORDER BY id DESC LIMIT 5").fetchall()
    conn.close()
    return render_template(
        "index.html",
        total=total,
        avg_marks=round(avg_marks, 2),
        avg_attendance=round(avg_attendance, 2),
        at_risk=at_risk,
        recent=recent,
    )


@app.route("/students")
def students():
    q = request.args.get("q", "").strip()
    conn = get_db()
    if q:
        rows = conn.execute(
            """SELECT * FROM students
               WHERE roll_no LIKE ? OR name LIKE ? OR course LIKE ?
               ORDER BY id DESC""",
            (f"%{q}%", f"%{q}%", f"%{q}%"),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM students ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("students.html", students=rows, q=q)


@app.route("/students/add", methods=["POST"])
def add_student():
    data = request.form
    try:
        conn = get_db()
        conn.execute(
            """INSERT INTO students
               (roll_no, name, email, course, semester, attendance, marks)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                data["roll_no"].strip(),
                data["name"].strip(),
                data["email"].strip(),
                data["course"].strip(),
                int(data["semester"]),
                float(data.get("attendance", 0)),
                float(data.get("marks", 0)),
            ),
        )
        conn.commit()
        conn.close()
        flash("Student added successfully.", "success")
    except (sqlite3.IntegrityError, ValueError, KeyError):
        flash("Please enter valid data. Roll number must be unique.", "error")
    return redirect(url_for("students"))


@app.route("/students/<int:student_id>/delete", methods=["POST"])
def delete_student(student_id):
    conn = get_db()
    conn.execute("DELETE FROM students WHERE id = ?", (student_id,))
    conn.commit()
    conn.close()
    flash("Student deleted.", "success")
    return redirect(url_for("students"))


@app.route("/api/students")
def api_students():
    conn = get_db()
    rows = conn.execute("SELECT * FROM students ORDER BY id DESC").fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])


@app.errorhandler(404)
def not_found(_):
    return render_template("base.html", error="Page not found."), 404


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
