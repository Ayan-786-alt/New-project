# Contributing

1. Create a feature branch.
2. Keep changes focused and readable.
3. Run `pytest` before opening a pull request.
4. Update the README when adding major features.
5. Use clear commit messages.
